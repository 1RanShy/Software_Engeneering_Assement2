package test;

import main.Model.Course;

public class CourseTest {
	public static void main(String[] args) {
		Course c = new Course("c00001", "Chemistry");
		System.out.println(c);
		// List<String> li = new ArrayList<String>();
		// String p1 = null;
		// li.add(p1);
		// String p2 = null;
		// li.add(p2);
		// System.out.println(li);
	}

}
