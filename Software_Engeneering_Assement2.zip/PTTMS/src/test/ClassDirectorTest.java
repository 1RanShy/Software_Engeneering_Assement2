// package test;
// import main.Model.ClassDirector;
// import main.Model.Requirement;

// public class ClassDirectorTest {
// 	public static void main(String[] args) {
// 		ClassDirector cd = new ClassDirector("sc00001", "Nick", "hfadghk");
// 		System.out.print(cd);
// 		Requirement r1 = new Requirement("sc00001", "c00001");
// 		cd.addRequirementList(r1);
// 		cd.addRequirementList(r1);
// 		System.out.print(cd);
// 	}
// }
