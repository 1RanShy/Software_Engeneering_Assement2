package main.Model;

// import java.util.ArrayList;
// import java.util.List;

public class Administrator extends Staff {
	public Administrator(String staffID, String staffName, String email) {
		super(staffID, staffName, email);
	}

	// public void checkTeachingRequirement() {

	// }

	// .
	// public void searchPTT() {

	// }

	// administratorID
	// public void addPTTtoTeachingRequirement(PTT Ptt, Requirement requirement) {
	// requirement.setPttId(Ptt.getStaffID());
	// }

	// public void addTrainingtoPTT(PTT ptt, String trainingID) {
	// ptt.setTrainingID(trainingID);
	// }
}
